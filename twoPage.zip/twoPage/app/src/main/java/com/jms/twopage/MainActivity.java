package com.jms.twopage;

import androidx.appcompat.app.AppCompatActivity;
import android.View.view;

import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void moveTwo(View v){
        Intent move = new Intent(this, nextPage.class);
            startActivity(move);

    }
}